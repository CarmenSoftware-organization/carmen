import RoleBasedOrderSystem from "../role-based-order-system"

export default function Page() {
  return <RoleBasedOrderSystem />
}
